//
//  Personagem.h
//  ExercicioClasse
//
//  Created by Usuário Convidado on 13/03/19.
//  Copyright © 2019 BrunoDalmasso. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Personagem : NSObject

@end

NS_ASSUME_NONNULL_END
