//
//  Personagem.m
//  ExercicioClasse
//
//  Created by Usuário Convidado on 13/03/19.
//  Copyright © 2019 BrunoDalmasso. All rights reserved.
//

#import "Personagem.h"

@implementation Personagem

@end
