//
//  Personagem.m
//  ExercicioClasse
//
//  Created by Usuário Convidado on 13/03/19.
//  Copyright © 2019 BrunoDalmasso. All rights reserved.
//

#import "Personagem.h"

@implementation Personagem

- (Personagem *) initWithNome:(NSString *)_nome andPoder:(int)_poder andVida:(float)_vida andEnergizado:(bool)_energizado {
    self = [super init];
    [self setNome: _nome];
    [self setPoder: _poder];
    [self setVida: _vida];
    [self setEnergizado: _energizado];
    
    return self;
}

- (void) calcularDanoWhitVida:(float)_vida andEnergizado:(bool)_energizado {
    if (_energizado) {
        poder = poder * 2;
    }
    if (_vida <= 5) {
        poder = poder * 4;
    }
}

-(NSString *) verificarVida:(float)_vida {
    return @"Seu personagem %@", vida <= 0 ? @"morto" : @"esta bem";
}

- (void) setNome: (NSString *)_nome {
    nome = _nome;
}

- (NSString *) getNome {
    return nome;
}

- (void) setPoder: (int)_poder {
    poder = _poder;
}

- (int) getPoder {
    return poder;
}

- (void) setVida: (float)_vida {
    vida = _vida;
}

- (float) getVida {
    return vida;
}

- (void) setEnergizado: (bool)_energizado {
    energizado = _energizado;
}

- (bool) getEnergizado {
    return energizado;
}

@end
