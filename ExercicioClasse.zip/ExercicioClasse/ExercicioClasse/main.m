//
//  main.m
//  ExercicioClasse
//
//  Created by Usuário Convidado on 13/03/19.
//  Copyright © 2019 BrunoDalmasso. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Personagem.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        Personagem *personagem = [[Personagem alloc] init];
        [personagem setNome: @"Dalma Obg"];
        [personagem setVida: 97.5];
        [personagem setPoder: 100];
        [personagem setEnergizado:false];
        
        NSLog(@"O %@ esta com %f de vida, %d de poder e %@ energizado.", [personagem getNome], [personagem getVida], [personagem getPoder], [personagem getEnergizado] ? @"esta" : @"nao" );
        
        Personagem *personagem2 = [[Personagem alloc] initWithNome: @"Arqueiro Orc" andPoder:75 andVida:40 andEnergizado: true];
        NSLog(@"O %@ esta com %f de vida, %d de poder e %@ energizado.", [personagem2 getNome], [personagem2 getVida], [personagem2 getPoder], [personagem2 getEnergizado] ? @"esta" : @"nao" );
        
        [personagem calcularDanoWhitVida:[personagem getPoder] andEnergizado:[personagem getEnergizado]];
        
        NSLog(@"O seu personagem esta %@ e o poder é %d", [personagem verificarVida:[personagem getVida]], [personagem getPoder]);
    }
    
    return 0;
}
