//
//  Personagem.h
//  ExercicioClasse
//
//  Created by Usuário Convidado on 13/03/19.
//  Copyright © 2019 BrunoDalmasso. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Personagem : NSObject {
    NSString *nome;
    int poder;
    float vida;
    bool energizado;
}

- (Personagem *) initWithNome:(NSString *)_nome andPoder:(int)_poder andVida:(float)_vida andEnergizado:(bool)_energizado;

- (void) setNome: (NSString *)_nome;
- (NSString *) getNome;

- (void) setPoder: (int)_poder;
- (int) getPoder;

- (void) setVida: (float)_vida;
- (float) getVida;

- (void) setEnergizado: (bool)_energizado;
- (bool) getEnergizado;

- (void) calcularDanoWhitVida:(float)_poder andEnergizado:(bool)_energizado;
-(NSString *) verificarVida:(float)_vida;

@end

NS_ASSUME_NONNULL_END
